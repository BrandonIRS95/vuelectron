/*
 Used to import GitHub Auth Token
 To Automate GitHub Updates
*/

module.exports = {
  token    : 'AN-OAUTH2-TOKEN',
  username : 'github-username',
  name     : 'Your Name',
  email    : 'user@email.com'
};