<template>
  <div class="ui container">
    <div class="ui menu">
      <div class="right menu">
        <a style="text-transform:capitalize;" class="item" v-for="option in options" v-bind:class="currentView === option ? 'active' : ''" v-on:click="currentView = option">
          {{option.name}}
          {{option.name === 'collection' ? '(' + collection.length + ')' : null}}
        </a>
      </div>
    </div>
    <transition v-on:enter="enter"
                v-on:leave="leave"
                v-bind:css="false"
                mode="out-in">
      <component v-bind:is="currentView"></component>
    </transition>
    <total v-if="currentView.name !== 'add-movie'"></total>
  </div>
</template>

<script>
  import Collection from './components/Collection.vue'
  import Market from './components/Market.vue'
  import MarketService from './components/MarketService.vue'
  import '../src/js/TweenMax.min'
  import Total from './components/Total.vue'
  import AddMovie from './components/AddMovie.vue'

  export default {
    name: 'app',
    data() {
      return {
        currentView: Market,
        options: [
          Collection,
          Market,
          AddMovie
        ],
        collection: MarketService.computed.getCollection()
      }
    },
    components: {
      Total
    },
    methods:{
      enter(el, done) {
        TweenMax.from(el, 0.2, {x: '20%', opacity: 0, onComplete: done})
      },
      leave(el, done) {
        TweenMax.to(el, 0.2, {x: '-20%', opacity: 0, onComplete: done})
      }
    }
  }
</script>

<style src="../semantic/dist/semantic.min.css"></style>
<style>
  body {
    padding: 30px;
  }
</style>
