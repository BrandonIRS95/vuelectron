<template>
    <div class="ui segment">
        <h2>Add Movie</h2>
        <div class="ui input">
            <input v-model="movie.name" type="text" placeholder="Name">
        </div>
        <div class="ui input">
            <input v-model="movie.type" type="text" placeholder="Type">
        </div>
        <div class="ui input">
            <input v-model.number="movie.price" type="text" placeholder="Price">
        </div>
        <div class="ui button" @click="addItem()">Add</div>
        <div class="ui green message" v-if="added">
            <div class="header">
                Movie {{movie.name}} added
            </div>
        </div>
    </div>
</template>
<script>
    import MarketService from './MarketService.vue'
    export default{
        name: 'add-movie',
        data() {
            return {
                movie: {
                    name: null,
                    type: null,
                    price: null
                },
                added: false
            }
        },
        methods: {
            addItem() {
                MarketService.computed.pushToMovies(this.movie)
                this.added = true
            }
        }
    }
</script>