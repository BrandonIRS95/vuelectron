<template>
    <div class="ui segment">
            <transition-group class="ui middle aligned divided list" v-if="movies.length > 0"
                        v-on:enter="enter"
                        v-on:leave="leave"
                        v-bind:css="false"
                        mode="out-in">
                <div class="item" v-for="(movie, index) in movies" :key="movie.name">
                    <div class="right floated content">
                        <div class="ui negative icon button" v-on:click="removeItem(index)">Remove from collection</div>
                    </div>
                    <div class="header">{{movie.name}} <span class="ui tag yellow label">${{movie.price}}</span></div>
                    <div class="description">{{movie.type}}</div>
                </div>
            </transition-group>
            <h3 v-else>Select some movies from the Market!</h3>
    </div>
</template>

<script>
    import MarketService from './MarketService.vue'
    export default{
        name: 'collection',
        data () {
            return {
                movies: MarketService.computed.getCollection()
            }
        },
        methods:{
            enter(el, done) {
                TweenMax.from(el, 0.2, {x: '10%', opacity: 0, onComplete: done})
            },
            leave(el, done) {
                TweenMax.to(el, 0.2, {x: '-10%', opacity: 0, onComplete: done})
            },
            removeItem(index){
                MarketService.computed.removeItem(index)
            }
        }
    }
</script>
