<template>
    <div class="ui segment">
        <div class="ui middle aligned divided list">
            <div class="item" v-for="(movie, index) in movies">
                <div class="right floated content">
                    <div class="ui positive icon button" v-on:click="addItem(movie)">
                        <span v-if="!collection.includes(movie)">Add to collection</span>
                        <i v-else class="checkmark icon"></i>
                    </div>
                </div>
                <div class="header">{{movie.name}} <span class="ui tag yellow label">${{movie.price}}</span></div>
                <div class="description">{{movie.type}}</div>
            </div>
        </div>
    </div>
</template>
<script>
    import MarketService from './MarketService.vue'
    export default{
        name: 'market',
        data () {
            return {
                movies: MarketService.computed.getMovies(),
                collection: MarketService.computed.getCollection()
            }
        },
        methods: {
            addItem(item) {
                MarketService.computed.pushMovie(item)
            }
        }
    }
</script>
