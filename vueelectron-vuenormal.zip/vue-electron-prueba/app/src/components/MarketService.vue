
<script>
    var data = {
        movies: [
            {name: 'Harry potter', type: 'Book', price: 50},
            {name: 'Muse', type: 'Book', price: 45},
            {name: 'Vanilla', type: 'Music', price: 12},
            {name: 'Tiffany', type: 'Cel', price: 65}
        ],
        collection: [],
        total: 0
    };

    export default{
        computed: {
            getMovies() {
                return data.movies;
            },
            pushMovie(movie) {
                if (data.collection.indexOf(movie) !== -1) return;
                data.collection.push(movie)
                var total = 0
                for(var x=0; x<data.collection.length; x++){
                    total += data.collection[x].price
                }
                data.total = total
            },
            pushToMovies(movie) {
                if (data.movies.indexOf(movie) !== -1) return;
                data.movies.push(movie)
            },
            getCollection() {
                return data.collection
            },
            getTotal() {
                var total = 0
                for(var x=0; x<data.collection.length; x++){
                    total += data.collection[x].price
                }
                return total
            },
            removeItem(index) {
                data.collection.splice(index,1)
            }
        }
    }
</script>