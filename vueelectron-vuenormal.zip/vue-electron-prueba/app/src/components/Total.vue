<template>
    <div class="ui segment">
        <h2>Total: ${{total}}</h2>
    </div>
</template>
<script>
    import MarketService from './MarketService.vue'
    export default{
        name: 'total',
        data() {
            return {
                movies: MarketService.computed.getCollection()
            }
        },
        computed: {
            total: function () {
                var total = 0
                for(var x=0; x<this.movies.length; x++){
                    total += this.movies[x].price
                }
                return total;
            }
        }
    }
</script>