export default [
  {
    path: '/',
    name: 'app',
    component: require('./App')
  },
  {
    path: '*',
    redirect: '/'
  }
]
